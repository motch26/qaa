const qaa = {
  host: "localhost",
  user: "root",
  password: "",
  port: 3306,
  database: "qaa",
};

module.exports = qaa;
