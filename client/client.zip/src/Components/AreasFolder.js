import React from "react";
import {
  Card,
  CardMedia,
  CardActionArea,
  CardContent,
  Typography,
  Grid,
} from "@mui/material";

import { areaFolder } from "../Theme/Home";

function AreasFolder({ folder, setSubShown }) {
  return (
    <Grid item md={4} xs={6} onClick={setSubShown}>
      <Card sx={areaFolder}>
        <CardActionArea>
          <CardMedia
            component="img"
            height="120"
            image="img/folder.jpg"
            alt="folder"
          />
          <CardContent>
            <Typography variant="h5" component="div">
              {folder.area}
            </Typography>
            <Typography variant="body1">{folder.description}</Typography>
          </CardContent>
        </CardActionArea>
      </Card>
    </Grid>
  );
}

export default AreasFolder;
