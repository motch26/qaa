import React from "react";
import { CssBaseline } from "@mui/material";
import { CookiesProvider } from "react-cookie";
import { BrowserRouter as Router } from "react-router-dom";
import MyRoutes from "./MyRoutes";

function App() {
  return (
    <Router>
      <CookiesProvider>
        <CssBaseline />
        <MyRoutes />
      </CookiesProvider>
    </Router>
  );
}

export default App;
