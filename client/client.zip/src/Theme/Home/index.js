export const areaFolder = {
  maxWidth: 345,
  "&:hover": {
    bgcolor: "#ff9800",
    maxWidth: 350,
    boxShadow: 2,
  },
};
